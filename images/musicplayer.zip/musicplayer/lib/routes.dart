import 'account.dart';

class AppRoutes {
  static const account = '/account';
  static const LOGIN = '/login';
  static const SETTINGS = '/settings';
}