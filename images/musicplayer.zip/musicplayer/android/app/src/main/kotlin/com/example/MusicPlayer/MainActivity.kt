package com.example.MusicPlayer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
